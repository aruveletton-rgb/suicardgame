"""Authoritative game engine components."""

