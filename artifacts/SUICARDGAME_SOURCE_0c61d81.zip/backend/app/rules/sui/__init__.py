"""Sui card rules."""

