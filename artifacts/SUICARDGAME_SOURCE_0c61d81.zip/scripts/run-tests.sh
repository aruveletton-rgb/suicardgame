#!/usr/bin/env bash
set -euo pipefail
python -m pytest -q backend/tests

