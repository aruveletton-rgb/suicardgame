"""Authoritative game engine components."""

