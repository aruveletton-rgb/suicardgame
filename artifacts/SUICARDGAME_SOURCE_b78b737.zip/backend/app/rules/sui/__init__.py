"""Sui card rules."""

